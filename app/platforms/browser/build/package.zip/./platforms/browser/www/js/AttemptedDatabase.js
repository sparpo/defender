// JavaScript source code
// Create DB and fill it with records
var DataBase = TAFFY([
	{"id":1,"School":"Rice College","Email":"joeycorbet@gmail.com"},
]);